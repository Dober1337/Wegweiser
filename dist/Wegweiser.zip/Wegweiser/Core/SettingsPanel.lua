-- ============================================================
-- Core/SettingsPanel.lua
-- Einstellungsfenster unter ESC -> Optionen -> AddOns -> Wegweiser.
--
-- Benutzt Blizzards modernes Settings-System (geprüft im Forever-
-- UI-Quellcode: Settings.RegisterVerticalLayoutCategory,
-- Settings.RegisterAddOnSetting, Settings.CreateCheckbox).
-- Die Häkchen schreiben direkt in WegweiserDB.settings.
-- ============================================================

local ADDON_NAME, ns = ...
local L = ns.L

-- Wird von Core/Settings.lua aufgerufen, sobald WegweiserDB geladen ist.
function ns:OnDatabaseReady()
    if not Settings or not Settings.RegisterVerticalLayoutCategory then
        return  -- Settings-API fehlt: dann eben ohne Fenster (Befehle gehen trotzdem)
    end

    local category = Settings.RegisterVerticalLayoutCategory(L.SETTINGS_TITLE)

    -- Ein Häkchen anlegen. key = Name in WegweiserDB.settings
    local function addCheckbox(key, label, tooltip)
        local setting = Settings.RegisterAddOnSetting(
            category,
            ADDON_NAME .. "_" .. key,   -- eindeutiger interner Name
            key,                        -- Schlüssel in der Tabelle
            ns.db.settings,             -- Tabelle, in die gespeichert wird
            "boolean",                  -- Typ
            label,                      -- angezeigter Text
            ns.defaults.settings[key]   -- Standardwert
        )
        Settings.CreateCheckbox(category, setting, tooltip)
    end

    -- Modul: Level-Up-Hinweise
    addCheckbox("levelUp",       L.OPT_LEVELUP,  L.OPT_LEVELUP_TT)
    addCheckbox("trainerHint",   L.OPT_TRAINER,  L.OPT_TRAINER_TT)
    addCheckbox("talentHint",    L.OPT_TALENT,   L.OPT_TALENT_TT)
    addCheckbox("loginReminder", L.OPT_LOGIN,    L.OPT_LOGIN_TT)
    addCheckbox("onScreen",      L.OPT_ONSCREEN, L.OPT_ONSCREEN_TT)
    -- Modul: Talent-Leitfaden
    addCheckbox("talentGuide",   L.OPT_GUIDE,    L.OPT_GUIDE_TT)
    addCheckbox("talentHighlight", L.OPT_HIGHLIGHT, L.OPT_HIGHLIGHT_TT)
    addCheckbox("talentShowFull",  L.OPT_SHOWFULL,  L.OPT_SHOWFULL_TT)
    -- Modul: Quest-Berater
    addCheckbox("questAdvisor",    L.OPT_QUESTS,    L.OPT_QUESTS_TT)
    addCheckbox("questOfferHint",  L.OPT_QOFFER,    L.OPT_QOFFER_TT)
    addCheckbox("questLogIcons",   L.OPT_QICONS,    L.OPT_QICONS_TT)
    addCheckbox("questAcceptHint", L.OPT_QACCEPT,   L.OPT_QACCEPT_TT)
    -- Zonen
    addCheckbox("zoneMapLevels",   L.OPT_MAPLVL,    L.OPT_MAPLVL_TT)
    addCheckbox("zoneAdvice",      L.OPT_ZADVICE,   L.OPT_ZADVICE_TT)
    -- Berufe
    addCheckbox("profHelper",      L.OPT_PROF,      L.OPT_PROF_TT)
    addCheckbox("profRouteBox",    L.OPT_PROFBOX,   L.OPT_PROFBOX_TT)

    addCheckbox("travelHints",     L.OPT_TRAVEL,    L.OPT_TRAVEL_TT)
    addCheckbox("gatherTooltip",   L.OPT_GATHERTT,  L.OPT_GATHERTT_TT)

    addCheckbox("invHints",        L.OPT_INV,       L.OPT_INV_TT)
    addCheckbox("merchantHelper",  L.OPT_MERCHANT,  L.OPT_MERCHANT_TT)
    addCheckbox("sessionMoney",    L.OPT_SESSIONMONEY, L.OPT_SESSIONMONEY_TT)

    addCheckbox("ridingHint",      L.OPT_RIDING,    L.OPT_RIDING_TT)
    addCheckbox("legacyHint",      L.OPT_LEGACY,    L.OPT_LEGACY_TT)

    addCheckbox("dungeonTab",      L.OPT_DTAB,      L.OPT_DTAB_TT)
    addCheckbox("dungeonHint",     L.OPT_DHINT,     L.OPT_DHINT_TT)

    addCheckbox("ahPrices",        L.OPT_AH,        L.OPT_AH_TT)
    addCheckbox("ahAutoScan",      L.OPT_AHAUTO,    L.OPT_AHAUTO_TT)
    -- Weitere Module (Talent-Leitfaden, Zonen, Quests, ...) kommen hier dazu,
    -- sobald sie gebaut sind.

    Settings.RegisterAddOnCategory(category)
    ns.settingsCategory = category
end

-- Öffnet das Einstellungsfenster (nur außerhalb des Kampfes).
function ns:OpenSettings()
    if not self.settingsCategory then return end
    self:RunOutOfCombat(function()
        Settings.OpenToCategory(self.settingsCategory:GetID())
    end)
end
