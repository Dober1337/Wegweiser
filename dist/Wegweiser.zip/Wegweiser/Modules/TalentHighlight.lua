-- ============================================================
-- Modules/TalentHighlight.lua
-- Modul 5b: Markierungen direkt im Blizzard-Talentfenster.
--
--   Sichtbar markiert wird NUR das Talent des aktuellen Build-Schritts
--   (Wunsch des Spielers: übersichtlich, nicht der ganze Baum):
--   * Ziel-Rang des Schritts darüber, z. B. "» 5/5" bei Donnernde Stöße.
--     Ist der Schritt fertig, wandert die Markierung zum nächsten Talent.
--   * Mit freiem Talentpunkt zusätzlich: pulsierender goldener Rahmen.
--   Im Tooltip (nur beim Drüberfahren) stehen für alle Build-Talente
--   Hinweise: "jetzt skillen", "später im Build", "wie geplant verteilt"
--   und bei Abweichungen ein gelber Hinweis, kein Zwang.
--
-- Technik (geprüft im Forever-UI-Quellcode, Build 1.60.1.70888):
--   * Das Talentfenster ist PlayerSpellsFrame.TalentsFrame aus dem Blizzard-Addon
--     "Blizzard_PlayerSpells". Es wird erst beim ersten Öffnen geladen –
--     deshalb setzen wir unsere Haken erst, wenn es geladen ist.
--   * TalentsFrame:GetTalentButtonByNodeID(nodeID) liefert den Knopf eines Talents.
--   * Blizzard meldet fertige Tooltips über EventRegistry
--     ("TalentDisplay.TooltipCreated") – dort hängen wir unsere Zeile an.
--   * Wir verändern KEINE Blizzard-Funktionen. Wir legen nur eigene, nicht
--     anklickbare Rahmen über die Knöpfe. Alles nur außerhalb des Kampfes.
-- ============================================================

local _, ns = ...
local L = ns.L

local Highlight = {}
ns.modules.TalentHighlight = Highlight

local GOLD  = { 1.0, 0.82, 0.0 }
-- Farben für "Build einblenden"
local GREEN = { 0.25, 0.9, 0.25 }    -- schon wie geplant verteilt
local BLUE  = { 0.3, 0.6, 1.0 }      -- kommt später im Build
local RED   = { 1.0, 0.25, 0.25 }    -- weicht vom Build ab
local CHECK_TEXTURE = "Interface\\RaidFrame\\ReadyCheck-Ready"

local overlays = setmetatable({}, { __mode = "k" })  -- Knopf -> unser Rahmen
local nodeState = {}      -- nodeID -> Infos für Markierung und Tooltip
local talentsFrame        -- PlayerSpellsFrame.TalentsFrame, sobald geladen
local refreshPending = false

local function settings()
    return ns.db and ns.db.settings or ns.defaults.settings
end

local function isEnabled()
    return settings().talentGuide and settings().talentHighlight
end

-- ------------------------------------------------------------
-- Unser Rahmen über einem Talent-Knopf
-- ------------------------------------------------------------

local function createOverlay(button)
    local o = CreateFrame("Frame", nil, button)
    o:SetPoint("TOPLEFT", button, "TOPLEFT", -4, 4)
    o:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", 4, -4)
    o:SetFrameLevel(button:GetFrameLevel() + 10)
    -- Wichtig: Maus geht durch unseren Rahmen hindurch auf den Blizzard-Knopf.
    o:EnableMouse(false)

    -- Goldener Rahmen aus vier Kanten (je 3 Pixel dick)
    local glow = CreateFrame("Frame", nil, o)
    glow:SetAllPoints()
    o.edges = {}
    local function edge(p1, p2, w, h)
        local t = glow:CreateTexture(nil, "OVERLAY")
        t:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 1)
        table.insert(o.edges, t)
        t:SetPoint(p1)
        t:SetPoint(p2)
        if w then t:SetWidth(w) end
        if h then t:SetHeight(h) end
    end
    edge("TOPLEFT", "TOPRIGHT", nil, 3)
    edge("BOTTOMLEFT", "BOTTOMRIGHT", nil, 3)
    edge("TOPLEFT", "BOTTOMLEFT", 3, nil)
    edge("TOPRIGHT", "BOTTOMRIGHT", 3, nil)
    -- Pulsieren, damit es auffällt
    local anim = glow:CreateAnimationGroup()
    anim:SetLooping("BOUNCE")
    local fade = anim:CreateAnimation("Alpha")
    fade:SetFromAlpha(1)
    fade:SetToAlpha(0.35)
    fade:SetDuration(0.7)
    o.glow, o.glowAnim = glow, anim

    -- Ziel-Rang für spätere Punkte, z. B. "» 3/5"
    local target = o:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    target:SetPoint("BOTTOM", o, "TOP", 0, 1)
    target:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
    target:SetShadowOffset(1, -1)
    o.target = target

    -- Häkchen für erledigte Talente
    local check = o:CreateTexture(nil, "OVERLAY")
    check:SetTexture(CHECK_TEXTURE)
    check:SetSize(16, 16)
    check:SetPoint("TOPRIGHT", o, "TOPRIGHT", 4, 4)
    o.check = check

    return o
end

-- Rahmenfarbe setzen (Gold, Grün, Blau, Rot)
local function setBorder(o, c)
    for _, t in ipairs(o.edges) do t:SetColorTexture(c[1], c[2], c[3], 1) end
end

local function hideOverlay(o)
    o.glowAnim:Stop()
    o.glow:Hide()
    o.target:Hide()
    o.check:Hide()
    o:Hide()
end

local function hideAll()
    for _, o in pairs(overlays) do hideOverlay(o) end
end

local function getOverlay(button)
    local o = overlays[button]
    if not o then
        o = createOverlay(button)
        overlays[button] = o
    end
    return o
end

-- ------------------------------------------------------------
-- Berechnen, welches Talent welchen Zustand hat
-- ------------------------------------------------------------

-- Füllt nodeState neu. Rückgabe: true, wenn etwas anzuzeigen ist.
local lastProblem   -- erstes Problem der Build-Prüfung (für den Hinweis im Talentfenster)

local function computeStates()
    wipe(nodeState)
    lastProblem = nil
    local guide = ns.modules.TalentGuide
    local build, tree = guide:Load()
    if not build then return false end
    local problems = guide:Validate(build, tree)
    if #problems > 0 then
        lastProblem = problems[1]
        return false
    end

    local points = guide:ExpandPoints(build)
    local progress = guide:GetProgress(build, tree)
    local _, unspent = ns.TalentAPI:GetPoints()
    unspent = unspent or 0

    -- Für jedes Talent im Build: nächster offener Punkt und Endrang
    for _, p in ipairs(points) do
        local nodeID = p.step.nodeID
        local live = tree.byNode[nodeID]
        local have = live and live.rank or 0
        local s = nodeState[nodeID]
        if not s then
            s = { have = have, want = build._finalRanks[nodeID], maxRank = p.step.maxRank }
            nodeState[nodeID] = s
        end
        if not s.nextPoint and have < p.targetRank then
            s.nextPoint = p
        end
    end
    -- Aktueller Schritt und sein Ziel-Rang (Rang am Ende dieses Schritts)
    local currentStep = progress.nextPoint and progress.nextPoint.step
    local stepTarget
    for _, p in ipairs(points) do
        if p.step == currentStep then stepTarget = p.targetRank end
    end
    if currentStep and nodeState[currentStep.nodeID] then
        nodeState[currentStep.nodeID].isCurrentStep = true
        nodeState[currentStep.nodeID].stepTarget = stepTarget
    end

    for nodeID, s in pairs(nodeState) do
        if progress.nextPoint and progress.nextPoint.step.nodeID == nodeID and unspent > 0 then
            s.state = "NOW"
        elseif s.have >= s.want then
            s.state = "DONE"
        else
            s.state = "LATER"
        end
        if s.state ~= "NOW" and s.nextPoint and progress.nextPoint == s.nextPoint then
            s.isNextButNoPoint = true   -- ist als Nächstes dran, aber noch kein freier Punkt
        end
    end
    -- Abweichungen (Punkte, die der Build so nicht vorsieht) – nur für den Tooltip
    for _, d in ipairs(progress.deviations) do
        local s = nodeState[d.live.nodeID] or { have = d.have, want = d.want, maxRank = d.live.maxRank }
        s.deviation = true
        s.state = s.state or "NONE"
        nodeState[d.live.nodeID] = s
    end
    return true
end

-- ------------------------------------------------------------
-- Markierungen zeichnen
-- ------------------------------------------------------------

local function frameUsable()
    if not talentsFrame or not talentsFrame:IsShown() then return false end
    -- Nur eigene, aktive Talente markieren (nicht beim Betrachten anderer
    -- Spieler und nicht auf dem Reiter der inaktiven Zweitspezialisierung).
    if talentsFrame.IsInspecting and talentsFrame:IsInspecting() then return false end
    if talentsFrame.IsActiveTabSelected and not talentsFrame:IsActiveTabSelected() then return false end
    return true
end

function Highlight:Refresh()
    refreshPending = false
    hideAll()
    if self.buildDropdown then
        self.buildDropdown:SetShown(isEnabled())
        if self.buildDropdown.GenerateMenu then self.buildDropdown:GenerateMenu() end
    end
    if self.toggleButton then
        self.toggleButton:SetShown(isEnabled())
        self.toggleButton:SetText(settings().talentShowFull and L.HL_BTN_HIDE or L.HL_BTN_SHOW)
    end
    if not isEnabled() or not frameUsable() then return end
    if ns:InCombat() then
        ns:RunOutOfCombat(function() Highlight:Refresh() end, true)
        return
    end
    local ok = computeStates()
    if self.problemText then
        -- Build passt nicht zum Baum: sichtbar machen statt einfach nichts anzuzeigen
        self.problemText:SetText(lastProblem and (L.HL_PROBLEM .. " " .. lastProblem) or "")
        self.problemText:SetShown(lastProblem ~= nil)
    end
    if not ok then return end

    local full = settings().talentShowFull
    for nodeID, s in pairs(nodeState) do
        local button = talentsFrame:GetTalentButtonByNodeID(nodeID)
        if button and button:IsShown() then
            if s.isCurrentStep then
                -- Aktueller Schritt: immer markiert (Ziel-Rang, Gold bei freiem Punkt)
                local o = getOverlay(button)
                o:Show()
                o.target:SetText(string.format("» %d/%d", s.stepTarget or s.want, s.maxRank))
                o.target:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
                o.target:Show()
                if s.state == "NOW" then
                    setBorder(o, GOLD)
                    o.glow:Show()
                    o.glowAnim:Play()
                elseif full then
                    setBorder(o, BLUE)
                    o.glow:Show()
                end
            elseif full then
                -- "Build einblenden": alle Build-Talente farbig, Abweichungen rot
                local o = getOverlay(button)
                local color
                if s.deviation then
                    color = RED
                elseif s.state == "DONE" then
                    color = GREEN
                elseif s.state == "LATER" then
                    color = BLUE
                    o.target:SetText(string.format("» %d/%d", s.want, s.maxRank))
                    o.target:SetTextColor(BLUE[1], BLUE[2], BLUE[3])
                    o.target:Show()
                end
                if color then
                    o:Show()
                    setBorder(o, color)
                    o.glow:Show()
                end
            end
        end
    end
end

-- "Build einblenden" an/aus
function Highlight:ToggleFull()
    settings().talentShowFull = not settings().talentShowFull
    ns:Print(settings().talentShowFull and L.HL_FULL_ON or L.HL_FULL_OFF)
    if self.toggleButton then
        self.toggleButton:SetText(settings().talentShowFull and L.HL_BTN_HIDE or L.HL_BTN_SHOW)
    end
    self:ScheduleRefresh()
end

-- Mehrere Ereignisse kurz hintereinander -> nur einmal neu zeichnen
function Highlight:ScheduleRefresh()
    if refreshPending then return end
    refreshPending = true
    C_Timer.After(0.15, function() Highlight:Refresh() end)
end

-- ------------------------------------------------------------
-- Tooltip-Zeile
-- ------------------------------------------------------------

local function onTooltip(_, button, tooltip)
    if not isEnabled() or not frameUsable() then return end
    if not button or not button.GetNodeID or not tooltip then return end
    local s = nodeState[button:GetNodeID()]
    if not s then return end
    local loc = ns.modules.TalentGuide.Loc

    tooltip:AddLine(" ")
    if s.state == "NOW" then
        local reason = s.nextPoint and loc(s.nextPoint.step.reason) or ""
        local text = reason ~= "" and string.format(L.HL_TT_NOW, reason) or L.HL_TT_NOW_SHORT
        tooltip:AddLine(text, GOLD[1], GOLD[2], GOLD[3], true)
    elseif s.state == "DONE" and not s.deviation then
        tooltip:AddLine(L.HL_TT_DONE, 0.3, 1.0, 0.3, true)
    elseif s.state == "LATER" and s.nextPoint then
        local text = s.isNextButNoPoint and L.HL_TT_NEXT or L.HL_TT_LATER
        tooltip:AddLine(string.format(text, s.isCurrentStep and s.stepTarget or s.want, s.maxRank, s.nextPoint.level), 0.75, 0.85, 1.0, true)
        local reason = loc(s.nextPoint.step.reason)
        if reason ~= "" then tooltip:AddLine(reason, 0.8, 0.8, 0.8, true) end
    end
    if s.deviation then
        tooltip:AddLine(string.format(L.HL_TT_DEVIATION, s.want or 0, s.have or 0), 1.0, 1.0, 0.0, true)
    end
    tooltip:Show()   -- Größe des Tooltips an die neuen Zeilen anpassen
end

-- ------------------------------------------------------------
-- Diagnose (/ww debug) – zeigt, an welcher Stelle es hakt
-- ------------------------------------------------------------

function Highlight:Diagnose()
    local function yn(v) return v and "|cff55ff55ja|r" or "|cffff5555nein|r" end
    ns:Print("Debug – Version %s", tostring(ns.version))
    ns:Print("  Einstellung talentGuide: %s, talentHighlight: %s",
        yn(settings().talentGuide), yn(settings().talentHighlight))
    ns:Print("  Blizzard_PlayerSpells geladen: %s", yn(C_AddOns.IsAddOnLoaded("Blizzard_PlayerSpells")))
    ns:Print("  PlayerSpellsFrame vorhanden: %s, TalentsFrame: %s",
        yn(PlayerSpellsFrame ~= nil), yn(PlayerSpellsFrame and PlayerSpellsFrame.TalentsFrame ~= nil))
    ns:Print("  Haken gesetzt: %s", yn(talentsFrame ~= nil))
    if talentsFrame then
        ns:Print("  Fenster sichtbar: %s", yn(talentsFrame:IsShown()))
        if talentsFrame.IsInspecting then ns:Print("  Betrachtet anderen Spieler: %s", yn(talentsFrame:IsInspecting())) end
        if talentsFrame.IsActiveTabSelected then ns:Print("  Aktiver Reiter gewählt: %s", yn(talentsFrame:IsActiveTabSelected())) end
    end
    local guide = ns.modules.TalentGuide
    local build, tree = guide:Load()
    ns:Print("  Build gefunden: %s", yn(build ~= nil))
    if build then
        local problems = guide:Validate(build, tree)
        ns:Print("  Build-Prüfung ohne Probleme: %s (%d)", yn(#problems == 0), #problems)
        local ok = computeStates()
        local count, found = 0, 0
        for nodeID in pairs(nodeState) do
            count = count + 1
            if talentsFrame and talentsFrame:GetTalentButtonByNodeID(nodeID) then found = found + 1 end
        end
        ns:Print("  Zustände berechnet: %s, Talente im Build: %d, davon Knöpfe gefunden: %d", yn(ok), count, found)
        local _, unspent = ns.TalentAPI:GetPoints()
        ns:Print("  Freie Talentpunkte: %s", tostring(unspent))
    end
end

-- ------------------------------------------------------------
-- Einrichten, sobald das Talentfenster geladen ist
-- ------------------------------------------------------------

local function setup()
    if talentsFrame then return end
    talentsFrame = PlayerSpellsFrame and PlayerSpellsFrame.TalentsFrame
    if not talentsFrame or not talentsFrame.GetTalentButtonByNodeID then
        talentsFrame = nil
        return
    end
    -- Nachträgliche Haken: Blizzards eigener Code läuft unverändert zuerst.
    talentsFrame:HookScript("OnShow", function()
        Highlight:ScheduleRefresh()
        -- Zweiter Versuch, falls Blizzard die Knöpfe beim ersten Mal noch nicht fertig hatte
        C_Timer.After(1, function() Highlight:ScheduleRefresh() end)
    end)
    talentsFrame:HookScript("OnHide", hideAll)

    -- Knopf "Build einblenden" unten links im Talentfenster (eigener Knopf)
    local btn = CreateFrame("Button", nil, talentsFrame, "UIPanelButtonTemplate")
    btn:SetSize(150, 22)
    btn:SetPoint("BOTTOMLEFT", talentsFrame, "BOTTOMLEFT", 16, 10)
    btn:SetFrameLevel(talentsFrame:GetFrameLevel() + 1500)
    btn:SetText(settings().talentShowFull and L.HL_BTN_HIDE or L.HL_BTN_SHOW)
    btn:SetScript("OnClick", function()
        if ns:InCombat() then return end
        Highlight:ToggleFull()
    end)
    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Wegweiser", 1, 0.82, 0)
        GameTooltip:AddLine(L.HL_LEGEND_NOW, GOLD[1], GOLD[2], GOLD[3])
        GameTooltip:AddLine(L.HL_LEGEND_DONE, GREEN[1], GREEN[2], GREEN[3])
        GameTooltip:AddLine(L.HL_LEGEND_LATER, BLUE[1], BLUE[2], BLUE[3])
        GameTooltip:AddLine(L.HL_LEGEND_OFF, RED[1], RED[2], RED[3])
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    btn:SetShown(isEnabled())
    Highlight.toggleButton = btn

    -- Auswahl des Leveling-Builds (Blizzard-Menü "WowStyle1DropdownTemplate",
    -- geprüft im Forever-UI-Quellcode, Blizzard_Menu)
    local dd = CreateFrame("DropdownButton", nil, talentsFrame, "WowStyle1DropdownTemplate")
    dd:SetPoint("LEFT", btn, "RIGHT", 8, 0)
    dd:SetWidth(230)
    dd:SetFrameLevel(talentsFrame:GetFrameLevel() + 1500)
    dd:SetDefaultText(L.HL_CHOOSE_BUILD)
    local guide = ns.modules.TalentGuide
    dd:SetupMenu(function(_, root)
        for _, b in ipairs(guide:GetClassBuilds()) do
            local ready = not b.planned and #(b.steps or {}) > 0
            local text = guide.Loc(b.menu or b.title) .. (ready and "" or (" " .. L.GUIDE_PLANNED))
                .. (b.beginner and (" " .. L.GUIDE_BEGINNER_TAG) or "")
            local radio = root:CreateRadio(text,
                function() return guide:GetBuild() == b end,
                function()
                    if ns:InCombat() then return end
                    guide:SelectBuild(b.key)
                    ns:Print(L.GUIDE_SELECTED, guide.Loc(b.title))
                    Highlight:ScheduleRefresh()
                end, b.key)
            if not ready and radio.SetEnabled then radio:SetEnabled(false) end
        end
    end)
    Highlight.buildDropdown = dd

    -- Roter Hinweis neben der Auswahl, falls der Build nicht zum Baum passt
    local problem = btn:CreateFontString(nil, "OVERLAY", "GameFontRedSmall")
    problem:SetPoint("LEFT", dd, "RIGHT", 8, 0)
    problem:SetPoint("RIGHT", talentsFrame, "BOTTOM", -110, 0)
    problem:SetJustifyH("LEFT")
    problem:SetWordWrap(false)
    problem:Hide()
    Highlight.problemText = problem
    if EventRegistry then
        EventRegistry:RegisterCallback("TalentDisplay.TooltipCreated", onTooltip, Highlight)
    end
    Highlight:ScheduleRefresh()
end

function Highlight:OnInitialize()
    if C_AddOns.IsAddOnLoaded("Blizzard_PlayerSpells") then
        setup()
    end
    ns:RegisterEvent("ADDON_LOADED", function(_, name)
        if name == "Blizzard_PlayerSpells" then setup() end
    end)
    -- Talente oder Punkte haben sich geändert -> neu zeichnen
    for _, event in ipairs({ "TRAIT_NODE_CHANGED", "TRAIT_CONFIG_UPDATED",
                             "TRAIT_TREE_CURRENCY_INFO_UPDATED", "PLAYER_LEVEL_UP" }) do
        ns:RegisterEvent(event, function()
            if talentsFrame and talentsFrame:IsShown() then Highlight:ScheduleRefresh() end
        end)
    end
end
